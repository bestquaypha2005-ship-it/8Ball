import Foundation

struct ShotPlanner {
    private func distance(_ a: Ball, _ p: Pocket) -> Double {
        hypot(a.x - p.x, a.y - p.y)
    }

    func plan(balls: [Ball], pockets: [Pocket], threshold: Double) -> ShotPlan? {
        guard let ball = balls.first else { return nil }
        guard let pocket = pockets.min(by: { distance(ball, $0) < distance(ball, $1) }) else { return nil }
        let dx = pocket.x - ball.x
        let dy = pocket.y - ball.y
        let angle = atan2(dy, dx) * 180 / .pi
        let d = hypot(dx, dy)
        let confidence = max(0, min(1, 1.0 - d * 0.45))
        let valid = confidence >= threshold
        return ShotPlan(ballID: ball.id, pocketID: pocket.id, angle: angle,
                        power: max(0.1, min(1.0, d * 0.9)),
                        confidence: confidence, valid: valid)
    }
}
