import SwiftUI

struct ContentView: View {
    @State private var autoPlay = false
    @State private var autoBreak = false
    @State private var luckyShot = false
    @State private var scanEnabled = true
    @State private var threshold = 0.80
    @State private var status = "READY"
    @State private var plan: ShotPlan?

    private let planner = ShotPlanner()
    private let balls = [Ball(id: 1, x: 0.55, y: 0.45)]
    private let pockets = [
        Pocket(id: 0, x: 0.03, y: 0.03), Pocket(id: 1, x: 0.50, y: 0.03), Pocket(id: 2, x: 0.97, y: 0.03),
        Pocket(id: 3, x: 0.03, y: 0.97), Pocket(id: 4, x: 0.50, y: 0.97), Pocket(id: 5, x: 0.97, y: 0.97)
    ]

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 14) {
                HStack {
                    Text("8 BALL POOL SIMULATOR").font(.system(size: 18, weight: .bold, design: .monospaced))
                    Spacer()
                    Text(status).foregroundStyle(.green).font(.system(.caption, design: .monospaced))
                }
                .foregroundStyle(.white)

                GroupBox("AUTO") {
                    VStack {
                        Toggle("Auto Play", isOn: $autoPlay)
                        Toggle("Auto Break", isOn: $autoBreak)
                        Toggle("Lucky Shot", isOn: $luckyShot)
                        Toggle("Table Scan", isOn: $scanEnabled)
                    }
                    .tint(.green)
                }

                GroupBox("PLANNER") {
                    VStack(alignment: .leading) {
                        Text("Confidence threshold: \(threshold, specifier: "%.2f")")
                        Slider(value: $threshold, in: 0.50...0.99, step: 0.01)
                        Button("SCAN + PLAN") { runPlanner() }
                            .buttonStyle(.borderedProminent)
                            .tint(.green)
                    }
                }

                GroupBox("SHOT") {
                    VStack(alignment: .leading, spacing: 6) {
                        if let p = plan {
                            Text("Ball: #\(p.ballID)   Pocket: #\(p.pocketID)")
                            Text("Angle: \(p.angle, specifier: "%.2f")°")
                            Text("Power: \(p.power, specifier: "%.2f")")
                            Text("Confidence: \(p.confidence, specifier: "%.3f")")
                                .foregroundStyle(p.valid ? .green : .red)
                        } else {
                            Text("No plan yet").foregroundStyle(.secondary)
                        }
                    }
                    .font(.system(.body, design: .monospaced))
                }
                Spacer()
                Text("SIMULATION ONLY • No game injection / server bypass")
                    .font(.caption2).foregroundStyle(.gray)
            }
            .padding()
        }
    }

    private func runPlanner() {
        status = scanEnabled ? "SCANNING" : "PLANNING"
        plan = planner.plan(balls: balls, pockets: pockets, threshold: threshold)
        status = plan?.valid == true ? "VALID SHOT" : "FAIL-SAFE"
    }
}
