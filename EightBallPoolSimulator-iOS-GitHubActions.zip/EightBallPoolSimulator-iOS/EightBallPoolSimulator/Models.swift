import Foundation

struct Ball: Identifiable {
    let id: Int
    var x: Double
    var y: Double
    var radius: Double = 0.03
}

struct Pocket: Identifiable {
    let id: Int
    var x: Double
    var y: Double
}

struct ShotPlan {
    var ballID: Int
    var pocketID: Int
    var angle: Double
    var power: Double
    var confidence: Double
    var valid: Bool
}
