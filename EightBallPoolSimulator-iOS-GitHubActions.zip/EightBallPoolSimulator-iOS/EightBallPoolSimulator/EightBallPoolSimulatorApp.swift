import SwiftUI

@main
struct EightBallPoolSimulatorApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
