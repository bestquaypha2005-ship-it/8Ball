# EightBallPoolSimulator iOS

SwiftUI iOS simulator with an ImGui-like dark control panel. It contains an offline shot-planning demo and does not inject into or modify third-party games.

## GitHub Actions

1. Upload this repository to GitHub.
2. Open **Actions** → **Build iOS Simulator**.
3. Run the workflow.
4. The workflow builds an unsigned `.app` for the iOS Simulator and uploads it as an artifact.

For installation on a physical iPhone, an Apple Developer signing setup is required. GitHub Actions alone does not make an unsigned simulator app installable on a real device.
